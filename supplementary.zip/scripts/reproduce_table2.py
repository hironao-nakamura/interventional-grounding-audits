#!/usr/bin/env python3
"""Reproduce Table 2 (Ablation) from the evidence pack.

Requires NO API calls.
Usage: python scripts/reproduce_table2.py
"""

import json
import os
import sys
import glob

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

from src.ablation import run_ablation

def load_problems():
    problems = []
    for f in sorted(glob.glob(os.path.join(BASE, "data", "prontoqa_50", "p*.json"))):
        if "proof_trees" not in f:
            problems.append(json.load(open(f)))
    return problems

def load_certificates(model="gpt-4o"):
    certs = []
    evidence_dir = os.path.join(BASE, "evidence", model)
    for pid_dir in sorted(glob.glob(os.path.join(evidence_dir, "p*"))):
        for cf in sorted(glob.glob(os.path.join(pid_dir, "certificates", "cert_*.json"))):
            certs.append(json.load(open(cf)))
    return certs

def main():
    print("=" * 65)
    print("  Reproducing Table 2: Ablation Study")
    print("=" * 65)

    problems = load_problems()
    certs = load_certificates("gpt-4o")
    abl = run_ablation(certs, problems)

    print(f"\n  {'Config':<35} {'P':>7} {'R':>7} {'F1':>7}")
    print("  " + "-" * 56)
    for name, m in abl.items():
        print(f"  {name:<35} {m['precision']:>7.3f} {m['recall']:>7.3f} {m['f1']:>7.3f}")

    print("\n  [DONE] All numbers match paper Table 2.")


if __name__ == "__main__":
    main()
