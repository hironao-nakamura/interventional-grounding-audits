#!/usr/bin/env python3
"""Reproduce ALL tables and analyses from the evidence pack.

Requires NO API calls.
Usage: python scripts/reproduce_all.py
"""

import subprocess
import sys
import os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

scripts = [
    "scripts/reproduce_table1.py",
    "scripts/reproduce_table2.py",
]

for script in scripts:
    path = os.path.join(BASE, script)
    print(f"\n{'#' * 65}")
    print(f"  Running: {script}")
    print(f"{'#' * 65}\n")
    subprocess.run([sys.executable, path], cwd=BASE)

print(f"\n{'=' * 65}")
print("  ALL REPRODUCTIONS COMPLETE")
print(f"{'=' * 65}")
