#!/bin/bash
# Full pipeline reproduction (requires API keys).
# This re-runs Phase 1 (LLM calls) and Phase 2 (evaluation).
#
# Prerequisites:
#   export OPENAI_API_KEY="your-key"
#   pip install openai anthropic
#
# Usage: bash scripts/run_full_pipeline.sh

echo "============================================"
echo "  Full Pipeline Reproduction"
echo "  Requires: OPENAI_API_KEY environment variable"
echo "============================================"

if [ -z "$OPENAI_API_KEY" ]; then
    echo "ERROR: OPENAI_API_KEY not set. Export it first."
    exit 1
fi

echo ""
echo "NOTE: This will make ~1,400 API calls to GPT-4o."
echo "Estimated cost: ~$15-25"
echo ""
read -p "Continue? [y/N] " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    exit 0
fi

echo "Running full experiment pipeline..."
echo "(Implementation note: adapt run_full_experiment.py to this directory structure)"
echo "For Phase 2 only (no API calls), use: python scripts/reproduce_all.py"
