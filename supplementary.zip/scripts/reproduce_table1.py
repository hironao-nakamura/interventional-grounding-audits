#!/usr/bin/env python3
"""Reproduce Tables 1-2 (Main Results) from the evidence pack.

Requires NO API calls. Uses pre-computed certificates only.
Usage: python scripts/reproduce_table1.py
"""

import json
import os
import sys
import glob

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

from src.ground_truth import (
    extract_ground_truth_dependencies,
    extract_pred_only_dependencies,
    classify_premise_type,
    _compute_prf1,
)
from src.ablation import run_ablation
from src.cascade_filter import apply_cascade_filter
from src.baseline_self_consistency import evaluate_baseline


def load_problems():
    problems = []
    for f in sorted(glob.glob(os.path.join(BASE, "data", "prontoqa_50", "p*.json"))):
        if "proof_trees" not in f:
            problems.append(json.load(open(f)))
    return problems


def load_certificates(model="gpt-4o"):
    certs = []
    evidence_dir = os.path.join(BASE, "evidence", model)
    for pid_dir in sorted(glob.glob(os.path.join(evidence_dir, "p*"))):
        for cf in sorted(glob.glob(os.path.join(pid_dir, "certificates", "cert_*.json"))):
            certs.append(json.load(open(cf)))
    return certs


def load_baseline():
    bl_dir = os.path.join(BASE, "baselines", "self_consistency", "gpt-4o")
    results = {}
    for f in sorted(glob.glob(os.path.join(bl_dir, "p*_samples.json"))):
        d = json.load(open(f))
        results[d["problem_id"]] = d
    return results


def judge_consistent_only(cert):
    """Re-judge using consistent substitution only (A alone)."""
    if not (cert.get("parse_ok_orig") and cert.get("parse_ok_sem") and cert.get("parse_ok_sur")):
        return "UNPARSEABLE"
    sem_delta = cert.get("semantic_delta", False)
    sur_delta = cert.get("surface_delta", False)
    if sem_delta and not sur_delta:
        return "GROUNDED"
    if sem_delta and sur_delta:
        return "INPUT-SENSITIVE"
    return "INSENSITIVE"


def compute_a_consistent_pred(certs, problems):
    """Compute A consistent (pred-only): consistent-only judging + pred-only GT."""
    tp = fp = fn = tn = 0

    gt_pred_map = {}
    for p in problems:
        gt = extract_pred_only_dependencies(p)
        for (sid, pid), dep in gt.items():
            gt_pred_map[(p["problem_id"], sid, pid)] = dep

    for cert in certs:
        verdict = judge_consistent_only(cert)
        if verdict == "UNPARSEABLE":
            continue

        key = (cert["problem_id"], cert["step_id"], cert["premise_id"])
        gt_dep = gt_pred_map.get(key)
        if gt_dep is None:
            continue

        predicted = verdict in ("GROUNDED", "INPUT-SENSITIVE")
        if predicted and gt_dep:
            tp += 1
        elif predicted and not gt_dep:
            fp += 1
        elif not predicted and gt_dep:
            fn += 1
        else:
            tn += 1

    p, r, f1 = _compute_prf1(tp, fp, fn)
    return {"precision": p, "recall": r, "f1": f1, "tp": tp, "fp": fp, "fn": fn}


def compute_cascade_filtered(certs, problems):
    """Compute A+A'+cascade (full): apply cascade filter, then evaluate against full GT."""
    filtered, n_cascaded = apply_cascade_filter(certs)

    gt_map = {}
    for p in problems:
        gt = extract_ground_truth_dependencies(p)
        for (sid, pid), dep in gt.items():
            gt_map[(p["problem_id"], sid, pid)] = dep

    tp = fp = fn = tn = 0
    for cert in filtered:
        verdict = cert.get("verdict", "UNPARSEABLE")
        if verdict in ("UNPARSEABLE", "INPUT-SENSITIVE", "UNSTABLE"):
            continue

        key = (cert["problem_id"], cert["step_id"], cert["premise_id"])
        gt_dep = gt_map.get(key)
        if gt_dep is None:
            continue

        predicted = verdict == "GROUNDED"
        if predicted and gt_dep:
            tp += 1
        elif predicted and not gt_dep:
            fp += 1
        elif not predicted and gt_dep:
            fn += 1
        else:
            tn += 1

    p, r, f1 = _compute_prf1(tp, fp, fn)
    return {"precision": p, "recall": r, "f1": f1, "tp": tp, "fp": fp, "fn": fn,
            "n_cascaded": n_cascaded}


def compute_fn_breakdown(certs, problems):
    """Compute FN breakdown for A consistent (full)."""
    gt_map = {}
    for p in problems:
        gt = extract_ground_truth_dependencies(p)
        for (sid, pid), dep in gt.items():
            gt_map[(p["problem_id"], sid, pid)] = dep

    fn_structural = 0
    fn_predicate = 0
    total_fn = 0
    prob_map = {p["problem_id"]: p for p in problems}

    for cert in certs:
        verdict = judge_consistent_only(cert)
        if verdict == "UNPARSEABLE":
            continue

        key = (cert["problem_id"], cert["step_id"], cert["premise_id"])
        gt_dep = gt_map.get(key, False)

        predicted = verdict in ("GROUNDED", "INPUT-SENSITIVE")

        if gt_dep and not predicted:
            total_fn += 1
            p = prob_map.get(cert["problem_id"])
            if p:
                ptype = classify_premise_type(p, cert["premise_id"])
                if ptype == "structural":
                    fn_structural += 1
                else:
                    fn_predicate += 1

    return {
        "total_fn": total_fn,
        "fn_structural": fn_structural,
        "fn_predicate_determining": fn_predicate,
        "structural_ratio": fn_structural / total_fn if total_fn > 0 else 0,
    }


def main():
    print("=" * 65)
    print("  Reproducing Table 1: Main Results (GPT-4o, ProntoQA 50)")
    print("=" * 65)

    problems = load_problems()
    certs = load_certificates("gpt-4o")
    print(f"  Loaded {len(problems)} problems, {len(certs)} certificates")

    # --- Ablation (gives us A consistent full, string-diff, etc.) ---
    abl = run_ablation(certs, problems)
    a_cons = abl.get("A_consistent_only", {})

    # --- A consistent pred-only ---
    a_pred = compute_a_consistent_pred(certs, problems)

    # --- A+A'+cascade (full) ---
    cascade = compute_cascade_filtered(certs, problems)

    # --- Self-consistency baseline ---
    bl_data = load_baseline()
    bl_full = evaluate_baseline(bl_data, problems, gt_type="full")

    # --- String-diff baseline ---
    sd = abl.get("string_diff_baseline", {})

    # ================================================================
    # Print Table 1
    # ================================================================
    print(f"\n  Table 1: Main Results")
    print(f"  {'Method':<30} {'P':>7} {'R':>7} {'F1':>7}")
    print("  " + "-" * 51)
    print(f"  {'Self-Consistency':<30} {bl_full['precision']:>7.3f} {bl_full['recall']:>7.3f} {bl_full['f1']:>7.3f}")
    print(f"  {'String-diff':<30} {sd.get('precision',0):>7.3f} {sd.get('recall',0):>7.3f} {sd.get('f1',0):>7.3f}")
    print(f"  {'A consistent (full)':<30} {a_cons.get('precision',0):>7.3f} {a_cons.get('recall',0):>7.3f} {a_cons.get('f1',0):>7.3f}")
    label_cascade = "A+A'+cascade (full)"
    print(f"  {label_cascade:<30} {cascade['precision']:>7.3f} {cascade['recall']:>7.3f} {cascade['f1']:>7.3f}")

    # ================================================================
    # Print Table 2: Pred-determining
    # ================================================================
    print(f"\n  Table 2: Predicate-Determining Dependencies")
    print(f"  {'Method':<30} {'P':>7} {'R':>7} {'F1':>7}")
    print("  " + "-" * 51)
    print(f"  {'A consistent (pred)':<30} {a_pred['precision']:>7.3f} {a_pred['recall']:>7.3f} {a_pred['f1']:>7.3f}")

    # ================================================================
    # FN Breakdown
    # ================================================================
    fn_info = compute_fn_breakdown(certs, problems)
    print(f"\n  FN breakdown (A consistent, full): {fn_info['total_fn']} total -> "
          f"{fn_info['fn_structural']} structural ({fn_info['structural_ratio']:.0%}), "
          f"{fn_info['fn_predicate_determining']} predicate-determining")

    # ================================================================
    # Expected values check
    # ================================================================
    print("\n  --- Verification against paper numbers ---")
    checks = [
        ("Self-Consistency F1", bl_full["f1"], 0.346, 0.005),
        ("A consistent (full) F1", a_cons.get("f1", 0), 0.783, 0.002),
        ("A consistent (pred) F1", a_pred["f1"], 0.835, 0.002),
        ("A+A'+cascade F1", cascade["f1"], 0.790, 0.005),
    ]
    all_ok = True
    for name, actual, expected, tol in checks:
        ok = abs(actual - expected) <= tol
        status = "OK" if ok else "MISMATCH"
        if not ok:
            all_ok = False
        print(f"    {name}: {actual:.3f} (expected {expected:.3f}) [{status}]")

    if all_ok:
        print("\n  [DONE] All numbers match paper Tables 1-2.")
    else:
        print("\n  [WARNING] Some numbers differ. Check tolerances.")


if __name__ == "__main__":
    main()
