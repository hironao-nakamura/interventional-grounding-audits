# Supplementary Material

## Interventional Grounding Audits for LLM Chain-of-Thought

This evidence pack accompanies the paper submission. It contains **all raw data,
certificates, and reproduction scripts** needed to verify every number in the paper.

---

## Quick Start (5 minutes)

```bash
pip install -r requirements.txt   # numpy only
python scripts/reproduce_all.py   # Reproduces ALL paper tables (NO API key needed)

# Or verify individual tables:
python scripts/reproduce_table1.py   # Table 1 (Main Results)
python scripts/reproduce_table2.py   # Table 2 (Ablation)
```

**Requirements:** Python 3.10+, see `requirements.txt` (numpy only).
No `openai` or `anthropic` packages needed for reproduction.

---

## Directory Structure

```
evidence/                    All certificate data
  gpt-4o/                   Main model (Tables 1-2)
    p001/                   Per-problem directory
      original_cot.json     Phase 1: original LLM output
      probes/               Probe outputs (semantic, local, surface)
      certificates/         Phase 2: deterministic verdicts
      problem_meta.json     Premises, question, proof tree
    final_report.json       Aggregate P/R/F1
    bootstrap_ci.json       10,000-iteration bootstrap CIs
    ablation.json           All ablation configurations
    fp_analysis.json        FP cause classification
    chain_length_analysis.json
    rawr_analysis.json      Right Answer Wrong Reasoning cases
    misrepresentation_analysis.json
  claude-sonnet-4/          Appendix B (same structure)

baselines/                  Self-consistency baseline data
  self_consistency/gpt-4o/  5 samples x 50 problems

data/prontoqa_50/           Input problems + proof trees

config/                     All parameters (externalized)
  audit_policy.json

src/                        Reproduction code
tests/                      Test suite
scripts/                    Reproduction scripts

checksums.sha256            SHA256 of all files
VALIDATION_LOG.txt          Automated validation results
```

---

## Certificate Schema Notes

Each certificate JSON contains the following fields:
- `problem_id`, `step_id`, `premise_id` — identifiers
- `verdict` — one of GROUNDED, INSENSITIVE, INPUT-SENSITIVE, UNSTABLE, UNPARSEABLE
- `decision_rule` — named rule that produced the verdict (e.g., R_GROUNDED_PRED_CHANGE)
- `semantic_delta`, `surface_delta` — boolean change indicators
- `parse_ok_orig`, `parse_ok_sem`, `parse_ok_sur` — parse success per output
- `verdict_consistent` — internal field from consistent-substitution judging (retained for traceability; can be ignored)

---

## Phase 1 / Phase 2 Separation

- **Phase 1** (`evidence/*/p*/probes/`): Raw LLM outputs. Non-deterministic.
  To re-run, you need an API key (`scripts/run_full_pipeline.sh`).

- **Phase 2** (`evidence/*/p*/certificates/`): Deterministic verdicts computed
  from Phase 1 outputs. `scripts/reproduce_table1.py` recomputes these from
  the included data — no API key needed.

Readers only need to verify Phase 2. Phase 1 data is included for
completeness and full reproducibility.

---

## Verification

1. **Checksums:** `sha256sum -c checksums.sha256` verifies no file was modified.
2. **Automated validation:** See `VALIDATION_LOG.txt` for the output of
   `src/validator.py` confirming schema compliance, referential integrity,
   and double-control consistency across all certificates.
3. **Reproduce numbers:** `python scripts/reproduce_all.py` recomputes every
   number in the paper from the raw certificates.

---

## Key Numbers (Paper Reference)

| Table | Metric | Value |
|-------|--------|-------|
| Table 1 | Our method F1 (full) | 0.783 |
| Table 1 | Self-consistency F1 | 0.346 |
| Table 1 | 95% CI gap | 0.351 (non-overlapping) |
| Table 2 | F1 (pred-determining) | 0.835 |
| Table 2 | Recall (pred-determining) | 97.4% |
| Table 1 | A+A'+cascade F1 | 0.790 |
| Analysis | RAWR cases | 14/50 (28%) |
| Analysis | MISREPRESENTATION cases | 12 |
| Appendix B | Claude F1 | 0.320 |
