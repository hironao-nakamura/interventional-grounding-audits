"""False Positive analysis for the main configuration (A consistent only).

For each FP certificate (verdict=GROUNDED but not in proof tree),
classify the cause into one of 5 types.
"""

import re
from collections import Counter, defaultdict


def classify_fp(cert, problem):
    """Classify a single false positive certificate."""
    phi_orig = cert.get("phi_original", "") or ""
    phi_sem = cert.get("phi_semantic", "") or ""
    step_id = cert.get("step_id", 0)
    prem_id = cert.get("premise_id", "P0")

    # --- Type 3: NORMALIZER_ERROR ---
    if phi_orig and phi_sem:
        orig_c = re.sub(r"\s+", "", phi_orig.lower())
        sem_c = re.sub(r"\s+", "", phi_sem.lower())
        if orig_c == sem_c:
            return "NORMALIZER_ERROR", (
                f"Normalized forms identical after cleanup: "
                f"'{phi_orig}' vs '{phi_sem}'"
            )

    # --- Type 1: STOCHASTIC (predicate change unrelated to substitution) ---
    if phi_orig and phi_sem:
        # Find the premise that was probed
        premise_text = ""
        for p in problem["premises"]:
            if p["id"] == prem_id:
                premise_text = p["text"]
                break

        # Extract predicates from orig and sem
        def extract_preds(form):
            m = re.match(r"(?:is|not_is|subtype|not_subtype)\((\w+),\s*(\w+)\)", form)
            if m:
                return m.group(1), m.group(2)
            return None, None

        subj_o, obj_o = extract_preds(phi_orig)
        subj_s, obj_s = extract_preds(phi_sem)

        if subj_o and subj_s:
            if subj_o == subj_s and obj_o != obj_s:
                # The object predicate changed
                changed_pred = obj_s
                # Does the changed predicate look like a proper substitution (zq prefix)?
                if changed_pred and changed_pred.startswith("zq"):
                    return "EXPECTED_SUBSTITUTION", (
                        f"Substituted predicate propagated correctly: "
                        f"'{obj_o}' -> '{changed_pred}'"
                    )
                else:
                    return "STOCHASTIC", (
                        f"Predicate changed from '{obj_o}' to '{obj_s}' "
                        f"without zq prefix — likely stochastic"
                    )
            elif subj_o != subj_s:
                return "STOCHASTIC", (
                    f"Subject changed from '{subj_o}' to '{subj_s}' — stochastic"
                )

    # --- Type 4: INDIRECT_DEPENDENCY (cascade from consistent substitution) ---
    # In ProntoQA, step N typically depends on premise N (chain) + entity premise.
    # If the FP is for a premise that is earlier in the chain, it could be
    # because the substitution propagated through the chain.
    proof_tree = problem.get("proof_tree", [])
    step_entry = next((e for e in proof_tree if e["step"] == step_id), None)
    if step_entry:
        direct_deps = [d for d in step_entry["depends_on"] if d.startswith("P")]
        if prem_id not in direct_deps:
            # This step doesn't directly depend on this premise
            # Check if ANY upstream step depends on this premise
            upstream_depends = False
            for e in proof_tree:
                if e["step"] < step_id:
                    if prem_id in [d for d in e["depends_on"] if d.startswith("P")]:
                        upstream_depends = True
                        break
            if upstream_depends:
                return "INDIRECT_DEPENDENCY", (
                    f"Step {step_id} doesn't directly depend on {prem_id}, "
                    f"but an upstream step does — substitution propagated through chain"
                )

    return "UNKNOWN", "Could not automatically classify"


def analyze_false_positives(certificates, problems):
    """Analyze all FPs for A consistent only configuration."""
    from src.ground_truth import extract_ground_truth_dependencies

    prob_map = {p["problem_id"]: p for p in problems}

    # Build GT positive set
    gt_positive = set()
    for p in problems:
        gt = extract_ground_truth_dependencies(p)
        for (sid, pid), dep in gt.items():
            if dep:
                gt_positive.add((p["problem_id"], sid, pid))

    # Find FPs (A consistent = verdict_consistent or verdict == GROUNDED)
    fps = []
    for cert in certificates:
        # Use combined verdict for the main config
        v = cert.get("verdict", "")
        if v != "GROUNDED":
            continue
        key = (cert["problem_id"], cert["step_id"], cert["premise_id"])
        if key not in gt_positive:
            fps.append(cert)

    # Classify
    classifications = []
    for fp in fps:
        pid = fp["problem_id"]
        problem = prob_map.get(pid)
        if not problem:
            continue
        fp_type, reason = classify_fp(fp, problem)
        classifications.append({
            "problem_id": pid,
            "step_id": fp["step_id"],
            "premise_id": fp["premise_id"],
            "type": fp_type,
            "reason": reason,
            "phi_original": fp.get("phi_original", ""),
            "phi_semantic": fp.get("phi_semantic", ""),
        })

    type_counts = Counter(c["type"] for c in classifications)
    return classifications, type_counts
