"""Evidence pack validator — parallel to Guard's RunDirWriter + auditor validation.

Validates the full evidence pack for artifact-checkable reproducibility:
1. Schema: every certificate has required fields
2. Referential integrity: certs point to existing problems/raw outputs
3. Checksum: SHA256 of raw outputs matches stored values
4. Double control: no GROUNDED where surface_delta=True
5. Coverage: every (step, premise) pair has a certificate
6. Decision rule consistency: verdict matches decision_rule
"""

import hashlib
import json
import os
import sys

# import config  # paths configured at runtime

REQUIRED_CERT_FIELDS = [
    "problem_id", "step_id", "premise_id",
    "phi_original", "phi_semantic", "phi_surface",
    "semantic_delta", "surface_delta",
    "verdict", "alignment_sem", "alignment_sur",
    "parse_ok",
]

VALID_VERDICTS = {"GROUNDED", "INSENSITIVE", "INPUT-SENSITIVE", "UNSTABLE", "UNPARSEABLE", "UNKNOWN"}


def validate_evidence_pack(data_dir: str = None, model_dir: str = None) -> dict:
    """Validate the full evidence pack.

    Parallel to Guard's auditor validation — ensures 100% artifact-checkable.

    Args:
        data_dir: Base data directory (default: config.DATA_DIR)
        model_dir: Model subdirectory name (e.g., "gpt-4o")

    Returns:
        Validation report dict with pass/fail for each check category.
    """
    data_dir = data_dir or config.DATA_DIR
    results = {
        "schema_ok": True,
        "referential_integrity_ok": True,
        "checksum_ok": True,
        "double_control_consistency_ok": True,
        "decision_rule_consistency_ok": True,
        "coverage_ok": True,
        "errors": [],
        "warnings": [],
        "stats": {},
    }

    # Load problems
    problems_dir = os.path.join(data_dir, "problems")
    problems = {}
    if os.path.isdir(problems_dir):
        for fn in sorted(os.listdir(problems_dir)):
            if fn.endswith(".json"):
                with open(os.path.join(problems_dir, fn)) as f:
                    p = json.load(f)
                    problems[p["problem_id"]] = p
    else:
        results["errors"].append("problems directory not found")
        results["referential_integrity_ok"] = False

    results["stats"]["n_problems"] = len(problems)

    if model_dir is None:
        # Auto-detect model dirs from results/
        results_base = os.path.join(data_dir, "results")
        if os.path.isdir(results_base):
            model_dirs = [d for d in os.listdir(results_base)
                          if os.path.isdir(os.path.join(results_base, d))]
        else:
            model_dirs = []
    else:
        model_dirs = [model_dir]

    for mdir in model_dirs:
        _validate_model(data_dir, mdir, problems, results)

    # Summary
    all_ok = (results["schema_ok"] and results["referential_integrity_ok"]
              and results["checksum_ok"] and results["double_control_consistency_ok"]
              and results["decision_rule_consistency_ok"]
              and results["coverage_ok"])
    results["all_ok"] = all_ok

    return results


def _validate_model(data_dir, model_dir, problems, results):
    """Validate a single model's evidence."""
    result_dir = os.path.join(data_dir, "results", model_dir)
    certs_file = os.path.join(result_dir, "certificates.json")

    if not os.path.exists(certs_file):
        results["errors"].append(f"[{model_dir}] certificates.json not found")
        results["schema_ok"] = False
        return

    with open(certs_file) as f:
        certificates = json.load(f)

    results["stats"][f"{model_dir}_n_certificates"] = len(certificates)

    # 1. Schema check
    for i, cert in enumerate(certificates):
        for field in REQUIRED_CERT_FIELDS:
            if field not in cert:
                results["errors"].append(
                    f"[{model_dir}] cert #{i} missing field: {field}")
                results["schema_ok"] = False

        if cert.get("verdict") not in VALID_VERDICTS:
            results["errors"].append(
                f"[{model_dir}] cert #{i} invalid verdict: {cert.get('verdict')}")
            results["schema_ok"] = False

    # 2. Referential integrity
    for cert in certificates:
        pid = cert.get("problem_id")
        if pid not in problems:
            results["errors"].append(
                f"[{model_dir}] cert references unknown problem: {pid}")
            results["referential_integrity_ok"] = False

        # Check raw output file exists
        raw_orig_path = os.path.join(data_dir, "raw", model_dir, pid, "original_cot.json")
        if pid in problems and not os.path.exists(raw_orig_path):
            results["warnings"].append(
                f"[{model_dir}] raw output missing for {pid}")

    # 3. Checksum validation (sample check on raw outputs)
    raw_dir = os.path.join(data_dir, "raw", model_dir)
    checksum_checked = 0
    checksum_failed = 0
    if os.path.isdir(raw_dir):
        for pid_dir in os.listdir(raw_dir):
            orig_file = os.path.join(raw_dir, pid_dir, "original_cot.json")
            if os.path.exists(orig_file):
                with open(orig_file) as f:
                    raw_data = json.load(f)
                if "raw_response" in raw_data and "sha256" in raw_data:
                    computed = hashlib.sha256(raw_data["raw_response"].encode()).hexdigest()
                    if computed != raw_data["sha256"]:
                        results["errors"].append(
                            f"[{model_dir}] SHA256 mismatch for {pid_dir}/original_cot.json")
                        results["checksum_ok"] = False
                        checksum_failed += 1
                    checksum_checked += 1

    results["stats"][f"{model_dir}_checksums_verified"] = checksum_checked
    results["stats"][f"{model_dir}_checksums_failed"] = checksum_failed

    # 4. Double control consistency
    for cert in certificates:
        verdict = cert.get("verdict")
        s_delta = cert.get("surface_delta")
        sem_delta = cert.get("semantic_delta")
        local_delta = cert.get("local_delta")

        # GROUNDED should have semantic/local delta AND NOT surface delta
        if verdict == "GROUNDED":
            if s_delta:
                results["errors"].append(
                    f"[{model_dir}] GROUNDED with surface_delta=True: "
                    f"{cert.get('problem_id')} S{cert.get('step_id')} {cert.get('premise_id')}")
                results["double_control_consistency_ok"] = False
            if not (sem_delta or local_delta):
                results["errors"].append(
                    f"[{model_dir}] GROUNDED without any semantic delta: "
                    f"{cert.get('problem_id')} S{cert.get('step_id')} {cert.get('premise_id')}")
                results["double_control_consistency_ok"] = False

    # 5. Decision rule consistency (if decision_rule field exists)
    rule_verdict_map = {
        "R_GROUNDED_PRED_CHANGE": "GROUNDED",
        "R_GROUNDED_CASCADE": "GROUNDED",
        "R_GROUNDED_BOTH": "GROUNDED",
        "R_INPUT_SENSITIVE_BOTH": "INPUT-SENSITIVE",
        "R_INSENSITIVE_NO_CHANGE": "INSENSITIVE",
        "R_MISREPRESENT_CITED": "INSENSITIVE",
        "R_UNSTABLE_SURFACE_ONLY": "UNSTABLE",
        "R_UNPARSEABLE_ORIG": "UNPARSEABLE",
        "R_UNPARSEABLE_SEM": "UNPARSEABLE",
        "R_UNPARSEABLE_LOCAL": "UNPARSEABLE",
        "R_UNPARSEABLE_SUR": "UNPARSEABLE",
        "R_UNPARSEABLE_ALIGN": "UNPARSEABLE",
    }
    for cert in certificates:
        rule = cert.get("decision_rule")
        if rule and rule in rule_verdict_map:
            expected_verdict = rule_verdict_map[rule]
            actual_verdict = cert.get("verdict")
            if actual_verdict != expected_verdict:
                results["errors"].append(
                    f"[{model_dir}] decision_rule {rule} expects {expected_verdict} "
                    f"but got {actual_verdict}")
                results["decision_rule_consistency_ok"] = False

    # 6. Coverage check
    for pid, problem in problems.items():
        n_steps = len(problem.get("proof_tree", []))
        n_premises = len(problem.get("premises", []))
        expected = n_steps * n_premises

        actual = sum(1 for c in certificates if c.get("problem_id") == pid)
        if actual != expected:
            results["warnings"].append(
                f"[{model_dir}] coverage gap for {pid}: "
                f"expected {expected} certs (steps={n_steps} × premises={n_premises}), "
                f"got {actual}")


def print_validation(results: dict) -> None:
    """Print validation report."""
    print("\n" + "=" * 60)
    print("  EVIDENCE PACK VALIDATION")
    print("=" * 60)

    checks = [
        ("Schema", results["schema_ok"]),
        ("Referential integrity", results["referential_integrity_ok"]),
        ("Checksums", results["checksum_ok"]),
        ("Double control consistency", results["double_control_consistency_ok"]),
        ("Decision rule consistency", results["decision_rule_consistency_ok"]),
        ("Coverage", results["coverage_ok"]),
    ]

    for name, ok in checks:
        status = "PASS" if ok else "FAIL"
        print(f"  {name:<35} {status}")

    if results["errors"]:
        print(f"\n  Errors ({len(results['errors'])}):")
        for e in results["errors"][:10]:
            print(f"    - {e}")
        if len(results["errors"]) > 10:
            print(f"    ... and {len(results['errors']) - 10} more")

    if results["warnings"]:
        print(f"\n  Warnings ({len(results['warnings'])}):")
        for w in results["warnings"][:10]:
            print(f"    - {w}")

    print(f"\n  Stats: {json.dumps(results['stats'], indent=2)}")

    overall = "ALL PASS" if results["all_ok"] else "SOME CHECKS FAILED"
    print(f"\n  >>> {overall} <<<")
    print("=" * 60)


if __name__ == "__main__":
    # Run validation on default data directory
    model_dir = sys.argv[1] if len(sys.argv) > 1 else None
    results = validate_evidence_pack(model_dir=model_dir)
    print_validation(results)
