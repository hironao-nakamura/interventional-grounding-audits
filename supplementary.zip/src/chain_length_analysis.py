"""Analyze how chain length (number of reasoning hops) affects
grounding detection accuracy.
"""

import numpy as np
from collections import defaultdict
from src.ground_truth import extract_ground_truth_dependencies, _compute_prf1


def analyze_chain_length(certificates, problems):
    """Group by chain length, compute P/R/F1 per group."""
    prob_map = {p["problem_id"]: p for p in problems}

    # Build GT per problem
    gt_by_problem = {}
    for p in problems:
        gt = extract_ground_truth_dependencies(p)
        gt_positive = set()
        for (sid, pid), dep in gt.items():
            if dep:
                gt_positive.add((sid, pid))
        gt_by_problem[p["problem_id"]] = gt_positive

    # Chain length = number of proof tree steps
    chain_lengths = {}
    for p in problems:
        chain_lengths[p["problem_id"]] = len(p["proof_tree"])

    # Group certs by problem
    certs_by_problem = defaultdict(list)
    for cert in certificates:
        certs_by_problem[cert["problem_id"]].append(cert)

    # Compute per-length metrics
    length_groups = defaultdict(lambda: {"tp": 0, "fp": 0, "fn": 0, "pids": []})

    for pid, certs in certs_by_problem.items():
        cl = chain_lengths.get(pid, 0)
        grp = length_groups[cl]
        grp["pids"].append(pid)

        gt_pos = gt_by_problem.get(pid, set())

        for cert in certs:
            sid = cert["step_id"]
            prem = cert["premise_id"]
            v = cert.get("verdict", "")

            if v in ("UNPARSEABLE", "INPUT-SENSITIVE", "UNSTABLE"):
                continue

            predicted = v == "GROUNDED"
            is_gt = (sid, prem) in gt_pos

            if predicted and is_gt:
                grp["tp"] += 1
            elif predicted and not is_gt:
                grp["fp"] += 1
            elif not predicted and is_gt:
                grp["fn"] += 1

    results = []
    for length in sorted(length_groups.keys()):
        g = length_groups[length]
        p, r, f1 = _compute_prf1(g["tp"], g["fp"], g["fn"])
        results.append({
            "chain_length": length,
            "n_problems": len(set(g["pids"])),
            "tp": g["tp"], "fp": g["fp"], "fn": g["fn"],
            "precision": round(p, 4),
            "recall": round(r, 4),
            "f1": round(f1, 4),
        })

    return results
